#!/bin/bash
set -e
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_NAME="Drive Inventory.app"
SRC="$HERE/$APP_NAME"
DEST="$HOME/Applications"

echo "Installing Drive Inventory..."
mkdir -p "$DEST"
xattr -dr com.apple.quarantine "$SRC" 2>/dev/null || true
rm -rf "$DEST/$APP_NAME"
cp -R "$SRC" "$DEST/"
xattr -dr com.apple.quarantine "$DEST/$APP_NAME" 2>/dev/null || true
echo "Installed to: $DEST/$APP_NAME"
open "$DEST/$APP_NAME"
echo "Done - you can close this window."
