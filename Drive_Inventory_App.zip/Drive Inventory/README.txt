Drive Inventory - install

Requirements:
  - Apple Silicon Mac (M1 or newer)
  - macOS 13 (Ventura) or newer

To install:
  1. Unzip this file (double-click it).
  2. RIGHT-CLICK "Setup.command" -> Open, then click Open again.
     (macOS blocks it on first run because the app is not notarized yet.)
  3. It copies Drive Inventory into your Applications folder and launches it.

First launch:
  - macOS will ask to access removable drives and Google Drive. Click Allow.
    The app only READS drives to catalog them - it never moves or deletes files.

If "Setup.command" will not open:
  - Open Terminal, type:  chmod +x   (with a trailing space),
    drag Setup.command into the window, press Return, then double-click it again.

Tip: drag the app from ~/Applications onto your Dock. Closing the window quits it.
